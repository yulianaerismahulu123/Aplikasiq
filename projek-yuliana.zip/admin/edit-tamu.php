<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-tamu.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from tamu where Id_Tamu='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="Nama_Tamu">Nama Tamu</label>
                        <input type="hidden" name="Id_Tamu" value="<?php echo $row['Id_Tamu']?>" class="form-control">
                        <input type="text" name="Nama_Tamu" value="<?php echo $row['Nama_Tamu']?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Tanggal_Lahir">Tanggal Lahir</label>
                        <input type="date" name="Tanggal_Lahir" value="<?php echo $row['Tanggal_Lahir']?>" class="form-control">
                    </div>

                       <div class="form-group">
                        <label for="Jenis_Kelamin">Jenis Kelamin</label>
                        <input type="text" name="Jenis_Kelamin" value="<?php echo $row['Jenis_Kelamin']?>" class="form-control">
                    </div>

                       <div class="form-group">
                        <label for="Alamat">Alamat</label>
                        <input type="text" name="Alamat" value="<?php echo $row['Alamat']?>" class="form-control">
                    </div>


                    <div class="form-group">
                        <label for="No_Telpon">No Telpon</label>
                        <textarea name="No_Telpon" class="form-control"><?php echo $row['No_Telpon']?></textarea>
                    </div>

                    <input type="submit" name="kirim" value="UBAH" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>