<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-reservasi.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from reservasi where Id_Reservasi='$id'");
                $row=$tampil->fetch_assoc();
                ?>

                <div class="form-group">
                        <label for="Id_Tamu">Id Tamu</label>
                        <input type="hidden" name="Id_Reservasi" value="<?php echo $row['Id_Reservasi']?>" class="form-control">
                        <input type="number" name="Id_Tamu" value="<?php echo $row['Id_Tamu]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Nama_Tamu">Nama Reservasi</label>
                        <input type="text" name="Nama_Tamu" value="<?php echo $row['Nama_Reservasi]?>" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Tgl_Check_In">Tgl_Check_In</label>
                        <input type="date" name="Tgl_Check_In" value="<?php echo $row['Tgl_Check_In]?>" class="form-control">
                    </div>

                      <div class="form-group">
                        <label for="Tgl_Check_Out">Tgl_Check_Out</label>
                       <input type="date" name="Tgl_Check_Out " value="<?php echo $row['Tgl_Check_In]?>" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="Type_Kamar">Type_Kamar</label>
                        <select name="Type_Kamar" class="form-control">
                            <option value="Presidential Room<">Presidential Room</option>
                            <option value="Delux Room<">Delux Room<</option>
                            <option value="Standart Room<">Standart Room<</option>
                            <option value="Singel Room<">Singel Room<</option>
                            <option value="Junior Suite Room<">Junior Suite Room<</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="Price_Permalam">Price_Permalam</label>
                        <input type="number" name="Price_Permalam" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Lama_Inap">Lama_Inap</label>
                        <input type="number" name="Lama_Inap" class="form-control">
                    </div>

                     <div class="form-group">
                        <label for="Total_Bayar">Total Bayar</label>
                        <input type="number" name="Total_Bayar" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="Metode_Bayar">Metode Bayar</label>
                        <select name="Metode_Bayar" class="form-control">
                            <option value="Cash">Cash </option>
                            <option value="Debit">Debit</option>
                            <option value="Krebit">Krebit</option>
                    </div>



                    <input type="submit" name="kirim" value="SIMPAN" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>