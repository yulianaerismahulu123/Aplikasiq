<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
        <h1>Data Reservasi</h1>
            <?php 

            if(@$_GET['pesan']=="inputBerhasil"){

            ?>
                    <div class="alert alert-success">
                    Penyimpanan Berhasil!
                    </div>
            <?php

            }

            ?>


            <?php 

            if(@$_GET['pesan']=="hapusBerhasil"){

            ?>
                    <div class="alert alert-success">
                    Data Berhasil Dihapus!
                    </div>
            <?php

            }

            ?>

            <?php 

            if(@$_GET['pesan']=="editBerhasil"){

            ?>
                    <div class="alert alert-success">
                    Perubahan Berhasil!
                    </div>
            <?php

            }

            ?>


        <table  class="table table-bordered table-hover" id="data-table">
        <thead>
            <tr>
                <th>Id Tamu</th><th>Nama_Reservasi</th><th>Tgl Check In</th><th>Tgl Check Out</th><th>Type Kamar</th><th>Price Permalam</th><th>Lama Inap</th><th>Total BayarS</th><th>Metode Bayar</th>
                <th>
                    <a href="input-reservasi.php">
                        <button class="btn btn-info glyphicon glyphicon-plus"></button>
                    </a>
                </th>
            </tr> 
        </thead> 
        <tbody>
        <?php

        include "../koneksi.php";
        $sql=$koneksi->query("select * from reservasi");

        while($row= $sql->fetch_assoc()){
        ?>

            <tr>
                <td><?php echo $row['Id_Tamu']?></td>
                <td><?php echo $row['Nama_Tamu']?></td>
                <td><?php echo $row['Tgl_Check_In']?></td>
                <td><?php echo $row['Tgl_Check_Out']?></td>
                <td><?php echo $row['Type_Kamar']?></td>
                <td><?php echo $row['Price_Permalam']?></td>
                <td><?php echo $row['Lama_Inap']?></td>
                <td><?php echo $row['Total_Bayar']?></td>
                <td><?php echo $row['Metode_Bayar']?></td>

                <td>
                    
                <a href="edit-reservasi.php?id=<?php echo $row['Id_Reservasi']?>">
                    <button class="btn btn-xs btn-danger glyphicon glyphicon-edit"></button>
                </a>

                <a href="hapus-Reservasi.php?id=<?php echo $row['Id_Reservasi']?>" onclick=" return confirm('Anda yakin menghapus data?')">
                    <button class="btn btn-xs btn-warning glyphicon glyphicon-remove"></button>
                </a>

                </td>
            </tr>

        <?php    
        }
        ?>
        </tbody>
        </table>
        </div>
    </div>
</div>


<?php include "footer.php";?>