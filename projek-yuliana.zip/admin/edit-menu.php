<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="proses-edit-menu.php" method="POST">
                <?php
                $id=$_GET['id'];
                include "../koneksi.php";
                $tampil=$koneksi->query("select * from menu where Id_Menu='$id'");
                $row=$tampil->fetch_assoc();
                ?>
                    <div class="form-group">
                        <label for="Nama">Nama</label>
                        <input type="hidden" name="Id_Menu" value="<?php echo $row['Id_Menu']?>" class="form-control">
                        <input type="text" name="Nama" value="<?php echo $row['Nama]?>" class="form-control">
                    </div>

                      <div class="form-group">
                        <label for="Deskripsi">Deskripsi</label>
                        <input type="text" name="Deskripsi" value="<?php echo $row['Deskripsi]?>" class="form-control">
                    </div>


                     <div class="form-group">
                        <label for="Category">Category</label>
                        <input type="hidden" name="Id_Menu" value="<?php echo $row['Id_Menu']?>" class="form-control">
                        <input type="text" name="Category" value="<?php echo $row['Category]?>" class="form-control">
                    </div>

                    <input type="submit" name="kirim" value="UBAH" class="btn btn-info">
                    <input type="reset" name="kosongkan" value="Kosongkan" class="btn btn-danger">
                </form>
            </div>
        </div>
    </div>

<?php include "footer.php";?>