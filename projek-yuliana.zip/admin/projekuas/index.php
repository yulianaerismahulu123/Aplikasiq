7<?php include "header.php"; ?>
		<!-- Awal script Slider/ Carousel -->
		<div id="contoh-carousel" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#contoh-carousel" data-slide-to="0" class="active"></li>
        <li data-target="#contoh-carousel" data-slide-to="1"></li>
        <li data-target="#contoh-carousel" data-slide-to="2"></li>
      </ol>

      <div class="carousel-inner" role="listbox">
			<!-- Awal script Slider pertama -->
        <div class="item active">
          <img src="images/hotel1.jpg" alt="Berisi keterangan gambar" style="width:200%; height: 500px;">
          <div class="carousel-caption">
            <h1>MASTER HOTEL</h1>
            <h4>Tempat Beristirahat</h4>
            <p>MASTER HOTEL</p>
            <a href="detail_slider1.php" class="btn btn-danger">Baca Lebih Lanjut</a>
          </div>
        </div><!-- Akhir script Slider pertama -->
				<!-- Awal script Slider kedua -->
        <div class="item">
          <img src="images/hotel.jpg" alt="Berisi keterangan gambar">
          <div class="carousel-caption">
            <h1>MASTER HOTEL</h1>
            <h4>Tempat Beristirahat</h4>
            <p>MASTER HOTEL</p>
            <a href="detail_slide.php" class="btn btn-danger">Baca Lebih Lanjut</a>
          </div>
          </div>
    </div>
		<!-- Awal script Button Geser Kiri dan Kanan -->
    <a class="left carousel-control" href="#contoh-carousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
    </a>
		
    <a class="right carousel-control" href="#contoh-carousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
    </a><!-- Akhir script Button Geser Kiri dan Kanan -->
		
    </div><!-- Akhir script Slider/Carousel -->
		
		<!-- Awal Jumbotron -->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
					<div class="jumbotron">
						<h2>MASTER HOTEL</h2>
						<p> Halo Selamat Datang Pemesanan kamar Hotel, MASTER HOTEL memberikan anda kenyamanan selama menginap tempat yang Nyaman , Bersih, Murah, Dan Berkulaitas muntuk para pelanggan</p>
						

				</div>
      </div>
		</div>
		</div><!-- Akhir Jumbotron -->
		
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal Panel -->
		<div class="row">
			<div class="panel panel-default">
				<div class="panel-body">
				<h2 style="text-muted"><span class="glyphicon glyphicon-list"></span> </h2>
				
        <p></p>
				
				<div class="row">
					<div class="col-md-4">
					<h3>RESTORAN </h3>
						<img src="images/restoran.jpg" class="img-thumbnail img-responsive">
						<p>Restoran hotel ini menawarkan pengalaman kuliner yang istimewa dengan suasana yang elegan. Menu beragam menyajikan hidangan lokal dan internasional yang lezat, disajikan dengan sentuhan kreatif. Pelayanan ramah dan dekorasi yang menawan membuat restoran ini menjadi tempat yang sempurna untuk menikmati makanan berkualitas tinggi dalam lingkungan yang menyenangkan<br/><a class="btn btn-danger btn-xs" href="restoran.php"role="button">Selengkapnya</a></p>
					</div>
					<div class="col-md-4">
					<h3>TEMPAT BERMAIN</h3>
						<img src="images/bermain.jpg" class="img-thumbnail img-responsive">
						<p>Hotel ini menyediakan tempat bermain yang ramah anak, dilengkapi dengan permainan interaktif dan area bermain yang aman. Didesain dengan keceriaan dan kreativitas, tempat bermain ini menawarkan pengalaman yang menyenangkan bagi keluarga yang menginap di hotel.<br/><a class="btn btn-info btn-xs" href="jenis tas.php"role="button">Selengkapnya</a></p>
					</div>
					<div class="col-md-4">
					<h3>EVENTS</h3>
						<img src="images/events.jpg" class="img-thumbnail img-responsive">
						<p>Hotel ini menjadi tuan rumah berbagai acara istimewa, mulai dari pertemuan bisnis hingga perayaan pribadi. Ruang perjamuan yang elegan dan dilengkapi dengan teknologi modern menciptakan latar yang sempurna. Dengan layanan perencanaan acara yang profesional, hotel ini memastikan setiap detail diatur dengan baik, menjadikan setiap event berkesan dan sukses.<br/><a class="btn btn-info btn-xs" href="jenis tas.php"role="button">Selengkapnya</a></p>
					</div>
				</div>
				</div>
      </div>

		</div><!-- Akhir Panel -->
		<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
					<div class="jumbotron">
						<h1>MASTER HOTEL</h1>
						<div class="container">
		       <div class="row">
			   <div class="col-md-4">
				<h3>Presidential Rooms</h3>
				<img src="images/president.jpg" height="200" width="200">
				<h4>RP 3.900.000/malam</h4>
			</div>
			<div class="col-md-4">
				<h3>Delux Rooms</h3>
				<img src="images/delux.jpg" height="200" width="200">
				<h4> RP 3.500.000/malam</h4>
			</div>
			<div class="col-md-4">
				<h3>Junior Suite Room</h3>
				<img src="image/junior.jpg" height="200" width="200">
				<h4> RP 3.100.000/malam</h4>
			</div>
		      </div>
		      </div>
		      </div>
		      </div>
		
<?php include "footer.php"; ?>