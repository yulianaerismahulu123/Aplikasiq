<?php include "header.php";?>
  
		<div class="container">
		<div class="row">
			<div class="col-md-6">	
				<div class="jumbotron">
				  <h1><b>ROOMS</b></h1>
				</div>
				<div class="container">
		       <div class="row">
			   <div class="col-md-3">
				<h3>Presidential Rooms</h3>
				<img src="images/president.jpg" height="200" width="200">
				<h4>RP 3.900.000/malam</h4>
				 <a href="kamar1.php" class="btn btn-primary">Lihat Detail</a>
				<a href="Booking.html" class="btn btn-primary">Book Now</a>
			</div>
			<div class="col-md-3">
				<h3>Delux Rooms</h3>
				<img src="images/delux.jpg" height="200" width="200">
				<h4> RP 3.500.000/malam</h4>
				 <a href="kamar2.html" class="btn btn-primary">Lihat Detail</a>
				<a href="Booking.html" class="btn btn-primary">Book Now</a>
			</div>
			<div class="col-md-3">
				<h3>Junior Suite Room</h3>
				<img src="images/junior.jpg" height="200" width="200">
				<h4> RP 3.100.000/malam</h4>
				 <a href="kamar3.html" class="btn btn-primary">Lihat Detail</a>
				<a href="Booking.html" class="btn btn-primary">Book Now</a>
			</div>
			<div class="col-md-3">
				<h3>Single Room</h3>
				<img src="images/sinngel.jpg" height="200" width="200">
				<h4> RP 1.000.000/malam</h4>
				 <a href="kamar4.html" class="btn btn-primary">Lihat Detail</a>
				<a href="Booking.html" class="btn btn-primary">Book Now</a>
			</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h3>Standar Room</h3>
				<img src="images/standart.jpg" height="200" width="200">
				<h4> Rp.700.000/malam</h4>
				 <a href="kamar5.html" class="btn btn-primary">Lihat Detail</a>
				<a href="Booking.html" class="btn btn-primary">Book Now</a>
			</div>
		<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h3>Family Room</h3>
				<img src="images/family.jpg" height="200" width="200">
				<h4> RP 2.000.000/malam</h4>
				 <a href="kamar6.html" class="btn btn-primary">Lihat Detail</a>
				<a href="Booking.html" class="btn btn-primary">Book Now</a>
			</div>
		</div>
	</div>

	<?php include "footer.php"; ?>