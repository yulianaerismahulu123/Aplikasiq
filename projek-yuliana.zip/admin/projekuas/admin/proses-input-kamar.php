<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

$nomor_kamar=$_POST['Nomor_Kamar'];
$type_kamar=$_POST['Type_Kamar'];
$price_permalam=$_POST['Price_Permalam'];
$status=$_POST['Status'];

include "../koneksi.php";

$simpan=$koneksi->query("insert into room(Nomor_Kamar,Type_Kamar,Price_Permalam,Status) 
                        values ('$nomor_kamar, '$type_kamar', '$price_permalam', '$status')");

if($simpan==true){

    header("location:tampil-kamar.php?pesan=inputBerhasil");
} else{
    echo "Error";
}




?>