<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php include "header.php"; ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
        <h1>Booking</h1>


            <?php 

            if(@$_GET['pesan']=="hapusBerhasil"){

            ?>
                    <div class="alert alert-success">
                    Data Berhasil Dihapus!
                    </div>
            <?php

            }

            ?>


        <table  class="table table-bordered table-hover" id="data-table">
        <thead>
            <tr>
                <th>Pemesanan</th><th></th>
            </tr> 
        </thead> 
        <tbody>
        <?php

        include "../koneksi.php";
        $sql=$koneksi->query("select * from reservasi");

        while($row= $sql->fetch_assoc()){
        ?>

            <tr>
                <td>
                  <b><?php echo $row['Id_Tamu']?></b> (<?php echo $row['Nama_Tamu']?>) -- <?php echo $row['Tgl_Check_In']?> <br><?php echo $row['Tgl_Check_Out']?> <br><?php echo $row['Type_Kamar']?> <br><?php echo $row['Price_Permalam']?> <br><?php echo $row['Lama_Inap']?><?php echo $row['Total_Bayar']?>
                 "<i><?php echo $row['Metode_Bayar']?></i>"
               </td>
                <td>
                <a href="hapus-reservasi.php?id=<?php echo $row['Id_Reservasi']?>" onclick=" return confirm('Anda yakin menghapus data?')">
                    <button class="btn btn-xs btn-warning glyphicon glyphicon-remove"></button>
                </a>
                </td>
            </tr>

        <?php    
        }
        ?>
        </tbody>
        </table>
        </div>
    </div>
</div>


<?php include "footer.php";?>