<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";
$Id_Reservasi=['Id_Reservasi'];
$id_tamu=$_POST['Id_Tamu'];
$nama_tamu=$_POST['Nama_Tamu']
$tgl_check_in=$_POST['Tgl_Check_In'];
$tgl_check_out=$_POST['Tgl_Check_Out'];
$type_kamar=$_POST['Type_Kamar'];
$price_permalam=$_POST['Price_Permalam'];
$lama_inap=$_POST['Lama_Inap'];
$total_bayar=$_POST['Total_Bayar'];
$metode_bayar=$_POST['Metode_Bayar'];

include "../koneksi.php";
$ubah=$koneksi->query("update reservasi set Id_Tamu='$id_tamu', Nama_Tamu='$nama_tamu',Tgl_Check_In= '$tgl_check_in', Tgl_Check_Out='$tgl_check_out', Type_Kamar='$type_kamar', Price_Permalam='$price_permalam', Lama_Inap'$lama_inap', Total_Bayar='$total_bayar', Metode_Bayar='$metode_bayar',
, where Id_Reservasi='$Id_Reservasi'");

if($ubah==true){

    header("location:tampil-reservasi.php?pesan=editBerhasil");
    
} else{
    echo "Error";
}

?>