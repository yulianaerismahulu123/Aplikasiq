<?php
  session_start();
  if (empty($_SESSION['user_id'])){
    header("location:../login.php");
  }
?>
<?php

include "../koneksi.php";

$id=$_POST['Id_Menu'];
$nama=$_POST['Nama'];
$deskripsi=$_POST['Deskripsi'];
$category=$_POST['Category'];
$ubah=$koneksi->query("update restoran set Nama='$nama', Deskripsi='$deskripsi, Price='$price', Category=$category', where Id_Menu='$id'");

if($ubah==true){

    header("location:tampil-menu.php?pesan=editBerhasil");
} else{
    echo "Error";
}

?>