<?php include "header.php";?>
  
		<div class="container">
		<div class="row">
			<div class="col-md-6">	
				<div class="jumbotron">
				  <h1><b>ROOMS</b></h1>
				</div>
				<div class="container">
		       <div class="row">
			   <div class="col-md-3">
				<h3>Presidential Room</h3>
				<img src="images/president.jpg" height="200" width="200">
				<h4>RP 2.000.000/malam</h4>
				 <a href="room-presidential.php" class="btn btn-primary">Lihat Detail</a>
				<a href="data-tamu.php" class="btn btn-primary">Book Now</a>
			</div>
			<div class="col-md-3">
				<h3>Delux Room</h3>
				<img src="images/delux.jpg" height="200" width="200">
				<h4> RP 1.500.000/malam</h4>
				 <a href="room-delux.php" class="btn btn-primary">Lihat Detail</a>
				<a href="data-tamu.php" class="btn btn-primary">Book Now</a>
			</div>
			<div class="col-md-3">
				<h3>Junior Suite Room</h3>
				<img src="images/junior.jpg" height="200" width="200">
				<h4> RP 1.250.000/malam</h4>
				 <a href="room-junior.php" class="btn btn-primary">Lihat Detail</a>
				<a href="data-tamu.php" class="btn btn-primary">Book Now</a>
			</div>
			<div class="col-md-3">
				<h3>Single Room</h3>
				<img src="images/sinngel.jpg" height="200" width="200">
				<h4> RP 1.000.000/malam</h4>
				 <a href="room-singgel.php" class="btn btn-primary">Lihat Detail</a>
				<a href="data-tamu.php" class="btn btn-primary">Book Now</a>
			</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h3>Standart Room</h3>
				<img src="images/standart.jpg" height="200" width="200">
				<h4> Rp 1.100.000/malam</h4>
				 <a href="room-standart.php " class="btn btn-primary">Lihat Detail</a>
				<a href="data-tamu.php" class="btn btn-primary">Book Now</a>
			</div>
		<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h3>Family Room</h3>
				<img src="images/family.jpg" height="200" width="200">
				<h4> RP 1.200.000/malam</h4>
				 <a href="room-family.php" class="btn btn-primary">Lihat Detail</a>
				<a href="data-tamu.php" class="btn btn-primary">Book Now</a>
			</div>
		</div>
	</div>

	<?php include "footer.php"; ?>